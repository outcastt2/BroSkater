using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Splines;
using Unity.Mathematics;

namespace BroSkater.Rails
{
    /// <summary>
    /// Represents a grindable rail path using Unity's Spline system
    /// </summary>
    [RequireComponent(typeof(SplineContainer))]
    [RequireComponent(typeof(GrindPath))] // Ensure GrindPath exists
    public class SplineGrindPath : MonoBehaviour
    {
        [Header("Rail Settings")]
        [SerializeField] private float maxSnapDistance = 1.5f;
        [SerializeField] private float entryAngleThreshold = 60f;
        [SerializeField] private bool canGrindInBothDirections = true;
        
        [Header("Physics")]
        [SerializeField] private float railFriction = 0.1f;
        [SerializeField] private float speedBoost = 1.2f;
        
        [Header("Collider")]
        [SerializeField] private float colliderRadius = 0.25f;
        [SerializeField] private bool generateCollider = true;
        [SerializeField] private LayerMask railLayer;
        
        [Header("Debug")]
        [SerializeField] private bool showDebugGizmos = true;
        [SerializeField] private int debugGizmoSegments = 20;
        [SerializeField] private Color railColor = Color.blue;
        [SerializeField] private Color normalColor = Color.green;
        [SerializeField] private Color tangentColor = Color.red;
        [SerializeField] private Color snapZoneColor = new Color(1f, 0.5f, 0f, 0.3f);
        
        // Components
        private SplineContainer splineContainer;
        private Spline spline;
        private CapsuleCollider railCollider;
        private GrindPath grindPath; // Reference to the mesh-based path
        
        // Stats
        private float totalLength;
        private List<GameObject> segmentColliders = new List<GameObject>(); // Added: Store references to created colliders
        
        // Public property to access the associated GrindPath
        public GrindPath AssociatedGrindPath => grindPath;
        
        // --- Added: Public getter for the spline --- 
        public Spline Spline => spline; 
        // ------------------------------------------
        
        // --- Added: Expose Spline Closed state --- 
        public bool IsClosed => spline != null && spline.Closed;
        // -----------------------------------------
        
        private void OnValidate()
        {
            if (splineContainer == null)
                splineContainer = GetComponent<SplineContainer>();
                
            if (splineContainer != null && splineContainer.Splines.Count > 0)
                spline = splineContainer.Splines[0];
                
            UpdateCollider();
        }
        
        private void Awake()
        {
            // Get components
            splineContainer = GetComponent<SplineContainer>();
            grindPath = GetComponent<GrindPath>(); // Get GrindPath component
            
            if (splineContainer == null)
            {
                Debug.LogError("SplineContainer not found!", this);
                return;
            }
            if (grindPath == null)
            {
                 Debug.LogError("GrindPath component not found!", this);
                return;
            }
            
            // Set layer to Rail if not already set - Can stay here or move to Start
            if (gameObject.layer != LayerMask.NameToLayer("Rail") && railLayer != 0)
                gameObject.layer = LayerMask.NameToLayer("Rail");
        }
        
        private void OnDisable()
        {
             ClearSegmentColliders();
        }
        
        private void Start()
        {
            // Ensure GrindPath has extracted points before we use them
            if (grindPath.PathPoints == null || grindPath.PathPoints.Count < 2)
            {
                Debug.LogWarning("GrindPath has not generated points before Start. Spline generation skipped.", this);
                // Optionally, try extracting points here if not done automatically?
                // grindPath.ExtractPathFromMesh(); // Consider implications
            }
            else
            {
                 // Generate the spline based on GrindPath
                 GenerateSplineFromGrindPath();
                 Debug.Log($"SplineGrindPath Start: After GenerateSplineFromGrindPath. Spline is null? {spline == null}", this);
            }
               
            // Calculate length *after* spline generation
            if (spline != null)
                 totalLength = SplineUtility.CalculateLength(spline, transform.localToWorldMatrix);
            else
                 Debug.LogWarning("Spline is null after Start. Cannot calculate length.", this);
                 
            Debug.Log($"SplineGrindPath Start: Calculated Total Length: {totalLength}", this);
        }
        
        /// <summary>
        /// Gets the total length of the spline
        /// </summary>
        public float GetTotalLength()
        {
            return totalLength;
        }
        
        /// <summary>
        /// Attempts to generate or update the collider for this rail using segments along the spline.
        /// </summary>
        private void UpdateCollider()
        {
            Debug.Log("[SplineGrindPath] UpdateCollider called.", this);

            if (!generateCollider || spline == null || spline.Count < 2) // Need at least 2 knots for a spline
            {
                Debug.Log("[SplineGrindPath] Condition not met for collider generation. Clearing existing.", this);
                ClearSegmentColliders(); // Clear any existing segment colliders if disabled
                // Optionally disable/remove the main collider if it exists
                if (railCollider == null) railCollider = GetComponent<CapsuleCollider>();
                if (railCollider != null) railCollider.enabled = false; // Disable main collider
                return;
            }

            // Ensure main single capsule collider is disabled (we're using segments)
            if (railCollider == null) railCollider = GetComponent<CapsuleCollider>();
            if (railCollider != null) 
            {
                railCollider.enabled = false;
                Debug.Log($"[SplineGrindPath] Disabled main CapsuleCollider on {gameObject.name}? {railCollider.enabled == false}", this);
            }
            else
            {
                Debug.Log($"[SplineGrindPath] No main CapsuleCollider found on {gameObject.name} to disable.", this);
            }

            ClearSegmentColliders(); // Remove old segments before creating new ones
            Debug.Log($"[SplineGrindPath] Generating {debugGizmoSegments} collider segments.", this);

            int segments = Mathf.Max(1, debugGizmoSegments); // Ensure at least 1 segment
            float step = 1f / segments;

            for (int i = 0; i < segments; i++)
            {
                float t1 = i * step;
                float t2 = (i + 1) * step;

                // Evaluate points and tangents in local space
                spline.Evaluate(t1, out float3 pos1_local, out float3 tan1_local, out float3 up1_local);
                spline.Evaluate(t2, out float3 pos2_local, out float3 tan2_local, out float3 up2_local);

                Vector3 segmentCenter_local = (Vector3)(pos1_local + pos2_local) * 0.5f;
                float segmentLength = Vector3.Distance(pos1_local, pos2_local);
                Vector3 segmentDirection_local = ((Vector3)(pos2_local - pos1_local)).normalized;

                // Create child GameObject for the collider segment
                GameObject segmentGO = new GameObject($"ColliderSegment_{i}");
                segmentGO.transform.SetParent(transform, false); // Child of the spline rail, worldPositionStays = false
                segmentGO.transform.localPosition = segmentCenter_local; // Position relative to parent
                segmentGO.layer = gameObject.layer; // Assign the same layer as the parent rail

                // Align the segment GameObject's UP (Y) axis with the segment direction
                if (segmentDirection_local != Vector3.zero)
                {
                    segmentGO.transform.localRotation = Quaternion.FromToRotation(Vector3.up, segmentDirection_local);
                }
                else
                {
                    segmentGO.transform.localRotation = Quaternion.identity;
                }

                // Add and configure the Capsule Collider
                CapsuleCollider segmentCollider = segmentGO.AddComponent<CapsuleCollider>();
                segmentCollider.isTrigger = true; // Rails are triggers
                segmentCollider.radius = colliderRadius;
                // Height needs to account for the hemispherical caps extending beyond the segment length
                segmentCollider.height = segmentLength + colliderRadius * 2f; 
                segmentCollider.center = Vector3.zero; // Centered within the child GameObject
                segmentCollider.direction = 1; // Height along local Y-axis

                segmentColliders.Add(segmentGO); // Keep track of created segments
            }
             Debug.Log($"[SplineGrindPath] Finished generating {segmentColliders.Count} collider segments.", this);
        }
        
        // Helper to clean up previously generated colliders
        private void ClearSegmentColliders()
        {
            if (segmentColliders == null) segmentColliders = new List<GameObject>();
            
            // Iterate backwards to safely remove while iterating
            for(int i = segmentColliders.Count - 1; i >= 0; i--)
            {
                 GameObject go = segmentColliders[i];
                 if (go != null)
                 {
                    // Use DestroyImmediate if potentially called from editor context
                    if (Application.isPlaying)
                        Destroy(go);
                    else
                        DestroyImmediate(go);
                 }
            }
            segmentColliders.Clear();
        }
        
        /// <summary>
        /// Checks if the player can grind this rail from the given position with the given velocity
        /// </summary>
        public bool CanGrind(Vector3 playerPosition, Vector3 playerVelocity, 
                            out Vector3 entryPoint, out Vector3 railTangent, out float distance)
        {
            entryPoint = Vector3.zero;
            railTangent = Vector3.forward;
            distance = 0f;
            
            if (spline == null || playerVelocity.magnitude < 0.1f)
                return false;
                
            // Find closest point on spline
            float t;
            Vector3 localPosition = transform.InverseTransformPoint(playerPosition);
            
            // Use float3 for SplineUtility and check return distance
            float dist = SplineUtility.GetNearestPoint(spline, (float3)localPosition, out float3 nearestPointF3, out t);
            // Consider it failed if distance is huge or t is invalid (e.g., outside [0,1])
            // A simpler check might be just checking if distance is within reasonable bounds
            if (dist > maxSnapDistance * 2.0f) // Example failure condition (adjust threshold as needed)
                return false;
                
            // Convert back to world space
            entryPoint = transform.TransformPoint((Vector3)nearestPointF3); // Cast back
            
            // Check if player is close enough
            float distToRail = Vector3.Distance(playerPosition, entryPoint);
            if (distToRail > maxSnapDistance)
                return false;
                
            // Get the tangent at this point
            // Use float3 for SplineUtility methods
            SplineUtility.Evaluate(spline, t, out float3 positionF3, out float3 tangentF3, out float3 normalF3);
            railTangent = transform.TransformDirection((Vector3)tangentF3).normalized; // Cast back
            
            // Check approach angle
            float approachAngle = Vector3.Angle(playerVelocity.normalized, railTangent);
            
            // If we can grind in both directions, check the opposite direction too
            if (canGrindInBothDirections)
            {
                float oppositeAngle = Vector3.Angle(playerVelocity.normalized, -railTangent);
                approachAngle = Mathf.Min(approachAngle, oppositeAngle);
                
                // If opposite direction is better, reverse the tangent
                if (oppositeAngle < approachAngle)
                {
                    railTangent = -railTangent;
                }
            }
            
            if (approachAngle > entryAngleThreshold)
                return false;
                
            // Calculate the distance along the spline
            distance = t * totalLength;
            
            return true;
        }
        
        /// <summary>
        /// Gets the point on the rail at the given distance
        /// </summary>
        public bool GetPointAtDistance(float distance, out Vector3 point, out Vector3 tangent, out bool isEndReached)
        {
            point = Vector3.zero;
            tangent = Vector3.forward;
            isEndReached = false;
            
            if (spline == null)
                return false;
                
            // Convert distance to normalized t (0-1)
            float t = 0f;
            if (totalLength > 0) // Avoid division by zero
                t = Mathf.Clamp01(distance / totalLength);
            
            // Check if we're at the end of the rail
            isEndReached = (t >= 0.99f || t <= 0.01f);
            
            // Evaluate spline at position t
            // Use float3 for SplineUtility methods
            SplineUtility.Evaluate(spline, t, out float3 localPositionF3, out float3 localTangentF3, out float3 localNormalF3);
            
            // Convert to world space
            point = transform.TransformPoint((Vector3)localPositionF3); // Cast back
            tangent = transform.TransformDirection((Vector3)localTangentF3).normalized; // Cast back
            
            return true;
        }
        
        /// <summary>
        /// Returns the nearest point on the rail to the given position
        /// </summary>
        public bool GetNearestPoint(Vector3 worldPosition, out Vector3 nearestPoint, out Vector3 tangent, out float distance)
        {
            nearestPoint = Vector3.zero;
            tangent = Vector3.forward;
            distance = 0f;
            
            Debug.Log($"SplineGrindPath GetNearestPoint: Spline is null? {spline == null}");
            if (spline == null)
                return false;
                
            // Convert to local space
            Vector3 localPosition = transform.InverseTransformPoint(worldPosition);
            
            // Find nearest point on spline
            float t;
            // Use float3 and check return distance
            float dist = SplineUtility.GetNearestPoint(spline, (float3)localPosition, out float3 nearestF3, out t);
            Debug.Log($"SplineGrindPath GetNearestPoint: SplineUtility.GetNearestPoint returned distance: {dist}");
            
            // --- Add Check for Non-Finite Distance --- 
            if (!float.IsFinite(dist))
            {
                Debug.LogWarning($"SplineGrindPath GetNearestPoint: SplineUtility returned non-finite distance ({dist}), failing.", this);
                return false;
            }
            // -----------------------------------------
            
            // Add a check for failure (e.g., large distance) - This might be redundant now but keep for safety
            if (dist > float.MaxValue * 0.5f) // Check if distance is valid
            {
                Debug.LogWarning($"SplineGrindPath GetNearestPoint: SplineUtility returned large distance ({dist}), failing.");
                return false;
            }
                
            // Evaluate at this position
            // Use float3 for SplineUtility methods
            SplineUtility.Evaluate(spline, t, out float3 positionF3, out float3 localTangentF3, out float3 normalF3);
            
            // Convert back to world space
            nearestPoint = transform.TransformPoint((Vector3)nearestF3); // Cast back
            tangent = transform.TransformDirection((Vector3)localTangentF3).normalized; // Cast back
            
            // Calculate distance along rail
            distance = t * totalLength;
            
            return true;
        }
        
        private void OnDrawGizmos()
        {
            if (!showDebugGizmos || splineContainer == null || splineContainer.Splines.Count == 0)
                return;
                
            Spline gizmoSpline = splineContainer.Splines[0];
            float length = SplineUtility.CalculateLength(gizmoSpline, transform.localToWorldMatrix);
            
            // Draw rail path
            Gizmos.color = railColor;
            
            // Draw spline segments
            for (int i = 0; i < debugGizmoSegments; i++)
            {
                float t1 = (float)i / debugGizmoSegments;
                float t2 = (float)(i + 1) / debugGizmoSegments;
                
                // Use float3 for SplineUtility methods
                SplineUtility.Evaluate(gizmoSpline, t1, out float3 p1F3, out _, out _);
                SplineUtility.Evaluate(gizmoSpline, t2, out float3 p2F3, out _, out _);
                
                Gizmos.DrawLine(transform.TransformPoint((Vector3)p1F3), transform.TransformPoint((Vector3)p2F3));
            }
            
            // Draw normals and tangents at intervals
            for (int i = 0; i < debugGizmoSegments; i += 4)
            {
                float t = (float)i / debugGizmoSegments;
                
                // Use float3 for SplineUtility methods
                SplineUtility.Evaluate(gizmoSpline, t, out float3 posF3, out float3 tanF3, out float3 upF3);
                Vector3 position = transform.TransformPoint((Vector3)posF3);
                Vector3 tangentDir = transform.TransformDirection((Vector3)tanF3).normalized;
                Vector3 normalDir = transform.TransformDirection((Vector3)upF3).normalized;
                
                // Draw tangent
                Gizmos.color = tangentColor;
                Gizmos.DrawRay(position, tangentDir * 0.5f);
                
                // Draw normal
                Gizmos.color = normalColor;
                Gizmos.DrawRay(position, normalDir * 0.5f);
            }
            
            // Draw snap zone at endpoints
            Gizmos.color = snapZoneColor;
            SplineUtility.Evaluate(gizmoSpline, 0f, out float3 startPosF3, out _, out _);
            SplineUtility.Evaluate(gizmoSpline, 1f, out float3 endPosF3, out _, out _);
            
            Vector3 startPos = transform.TransformPoint((Vector3)startPosF3);
            Vector3 endPos = transform.TransformPoint((Vector3)endPosF3);
            
            Gizmos.DrawWireSphere(startPos, maxSnapDistance);
            Gizmos.DrawWireSphere(endPos, maxSnapDistance);
        }

        // New method to generate the spline
        // [ContextMenu("Generate Spline from Grind Path")] // Remove or comment out ContextMenu if auto-gen is reliable
        public void GenerateSplineFromGrindPath()
        {
            if (grindPath == null || splineContainer == null)
            {
                Debug.LogError("Missing GrindPath or SplineContainer component.", this);
                return;
            }

            List<Vector3> worldPoints = grindPath.PathPoints;

            if (worldPoints == null || worldPoints.Count < 2)
            {
                Debug.LogError("GrindPath does not contain enough points to generate a spline.", this);
                return;
            }

            // Get or create the spline object
            if (splineContainer.Spline == null)
            {
                spline = splineContainer.AddSpline();
            }
            else
            {
                spline = splineContainer.Spline;
                spline.Clear(); // Clear existing knots
            }

            Debug.Log($"Generating spline from {worldPoints.Count} GrindPath points.", this);
            // --- Add Log --- 
            if (worldPoints.Count > 0) 
            {
                Debug.Log($"GenerateSpline: First world point received: {worldPoints[0]}, Last world point: {worldPoints[worldPoints.Count-1]}");
            }
            // ---------------

            // Add knots to the spline based on GrindPath points
            for (int i = 0; i < worldPoints.Count; i++)
            {
                // Convert world point to local space for the spline knot
                Vector3 localPoint = transform.InverseTransformPoint(worldPoints[i]);
                
                // Create a new knot at the local position
                // We can add tangent calculations later for smoother curves if needed
                BezierKnot knot = new BezierKnot((float3)localPoint);
                // --- Add Log --- 
                Debug.Log($"GenerateSpline: Adding Knot {i}: World={worldPoints[i]}, Local={localPoint}");
                // ---------------
                spline.Add(knot);
            }
            
            // Unity often handles tangents automatically, but we can set them for more control if needed
            // For example, set auto-smooth tangents:
            spline.SetTangentMode(TangentMode.AutoSmooth);

            // --- Check if the path should be closed --- 
            bool isLoop = false; // Default to false
            float loopThreshold = 0.1f; // Match GrindPath threshold
            if (worldPoints.Count > 2)
            {
                float startEndDistance = Vector3.Distance(worldPoints[0], worldPoints[worldPoints.Count - 1]);
                isLoop = startEndDistance < loopThreshold;
            }
            spline.Closed = isLoop; // Set spline closed state
            Debug.Log($"[{gameObject.name} SplineGrindPath] Setting Spline.Closed = {spline.Closed}");
            // -----------------------------------------

            // --- Determine Primary Axis --- 
            int primaryAxis = 0; // Default to X
            if (spline.Knots.Count() > 1)
            {
                Vector3 firstKnotPos = (Vector3)spline.Knots.First().Position;
                Vector3 lastKnotPos = (Vector3)spline.Knots.Last().Position;
                Vector3 delta = lastKnotPos - firstKnotPos;
                float absX = Mathf.Abs(delta.x);
                float absY = Mathf.Abs(delta.y);
                float absZ = Mathf.Abs(delta.z);

                if (absY > absX && absY > absZ)
                    primaryAxis = 1; // Y-axis is dominant
                else if (absZ > absX && absZ > absY)
                    primaryAxis = 2; // Z-axis is dominant
                
                Debug.Log($"Spline primary axis detected as: {primaryAxis} (0=X, 1=Y, 2=Z)", this);
            }
            // ------------------------------

            // Recalculate length 
            totalLength = SplineUtility.CalculateLength(spline, transform.localToWorldMatrix);

            // --- Generate / Update Collider Directly Here --- 
            if (generateCollider)
            {
                if (railCollider == null)
                    railCollider = GetComponent<CapsuleCollider>();
                if (railCollider == null)
                    railCollider = gameObject.AddComponent<CapsuleCollider>();
                
                railCollider.isTrigger = true;
                railCollider.radius = colliderRadius;
                railCollider.height = totalLength;
                railCollider.direction = primaryAxis; // Use axis calculated above

                // Set Center based on knots (if available)
                if (spline.Knots.Count() > 1)
                {
                    Vector3 firstKnotPos = (Vector3)spline.Knots.First().Position;
                    Vector3 lastKnotPos = (Vector3)spline.Knots.Last().Position;
                    railCollider.center = (firstKnotPos + lastKnotPos) * 0.5f;
                }
                else
                {
                    railCollider.center = Vector3.zero;
                }
            }
            // ------------------------------------------
            
            Debug.Log($"Spline generated. Total length: {totalLength:F2}m", this);
            
            // Optional: Notify editor that changes were made if running in editor
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(splineContainer);
            #endif

            // Recalculate total length after spline generation
            totalLength = SplineUtility.CalculateLength(spline, transform.localToWorldMatrix);
            Debug.Log($"Spline generated from GrindPath. New Total Length: {totalLength:F2}m", this);

            // Generate/Update colliders AFTER spline is generated
            UpdateCollider(); 
        }
    }
} 