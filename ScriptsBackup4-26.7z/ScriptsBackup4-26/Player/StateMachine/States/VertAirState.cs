using UnityEngine;
using BroSkater.Player;
using BroSkater.Player.StateMachine;
using BroSkater.Rails;

namespace BroSkater.Player.States
{
    /// <summary>
    /// State entered after launching off a vert ramp lip.
    /// May have slightly different physics/gravity than normal air.
    /// </summary>
    public class PlayerVertAirState : PlayerState
    {
        // TODO: Define specific vert air parameters if needed (e.g., modified gravity)
        private const float VERT_GRAVITY_MULTIPLIER = 0.9f; // Slightly less gravity than normal air?
        private const float VERT_AIR_CONTROL_FORCE = 6.0f; // Potentially different air control
        
        // Store info about the launch surface
        private Vector3 launchNormal;
        private Vector3 launchPoint;
        private bool hasVertInfo = false;
        private Vector3 initialJumpVelocity = Vector3.zero; // Store the velocity
        private bool hasPendingJumpVelocity = false;

        public PlayerVertAirState(PlayerStateMachine stateMachine, PlayerController player) : base(stateMachine, player) { }

        /// <summary>
        /// Special Enter method called when transitioning from a detected Vert launch.
        /// Stores launch info before the standard Enter logic runs.
        /// </summary>
        public void EnterWithVertInfo(Vector3 normal, Vector3 point)
        {
            launchNormal = normal;
            launchPoint = point;
            hasVertInfo = true;
            Debug.Log($"PlayerVertAirState received Vert Info: Normal={launchNormal}, Point={launchPoint}");
            // The actual state change in PlayerStateMachine will still call the standard Enter() next.
        }

        /// <summary>
        /// Sets the initial velocity to be applied when entering the state.
        /// </summary>
        public void SetInitialJumpVelocity(Vector3 velocity)
        {
            initialJumpVelocity = velocity;
            hasPendingJumpVelocity = true;
            Debug.Log($"PlayerVertAirState received InitialJumpVelocity: {velocity}");
        }

        public override void Enter()
        {
            Debug.Log("Entering Player Vert Air State");
            player.IsGrounded = false;
            // Any specific setup for vert air? Maybe trigger an animation?
            // TODO: Potentially add a flag player.IsInVertAir = true;

            // Apply pending jump velocity if it was set
            if (hasPendingJumpVelocity)
            {
                player.Velocity = initialJumpVelocity;
                hasPendingJumpVelocity = false; // Consume the flag
                Debug.Log($"Applied initial jump velocity: {player.Velocity}");
            }
            else if (hasVertInfo)
            {
                // TODO: Potentially use launchNormal or launchPoint to influence initial air velocity or rotation?
                // For example, add a small boost away from the launch normal?
                // player.Velocity += launchNormal * 2f; 
                
                hasVertInfo = false; // Reset flag after using info
            }
        }

        public override void LogicUpdate()
        {
            // Check for landing
            player.CheckGrounded();
            if (player.IsGrounded)
            {
                stateMachine.ChangeState(stateMachine.SkatingState);
                return;
            }

            // Check for grind input
            HandleGrindInput();
            
            // Check for manual landing attempt (if applicable)
            // HandleManualLanding();
        }

        public override void PhysicsUpdate()
        {
            float dt = Time.fixedDeltaTime;

            ApplyVertGravity(dt);
            HandleAirControl(dt);
            HandleRotation(dt);
            LimitAirSpeed();
        }

        private void ApplyVertGravity(float dt)
        {
             // Apply gravity force (potentially modified)
            player.Velocity += Physics.gravity * VERT_GRAVITY_MULTIPLIER * dt;
        }
        
        private void HandleAirControl(float dt)
        {
            Vector2 moveInput = inputHandler.MoveInput;
            if (moveInput.magnitude > 0.1f)
            {
                // Simplified air control using camera relative directions
                Vector3 forward = player.Forward; // Use player forward for consistency for now
                Vector3 right = player.Right;

                Vector3 controlDirection = (right * moveInput.x + forward * moveInput.y).normalized;
                
                // Apply air control force
                player.Velocity += controlDirection * VERT_AIR_CONTROL_FORCE * dt;
            }
        }

        private void HandleRotation(float dt)
        {
             // Basic air rotation based on input and spin stat
             float rotationInput = inputHandler.MoveInput.x; // Or dedicated rotation input if available
             if (Mathf.Abs(rotationInput) > 0.1f)
             {
                 float rotationSpeed = Mathf.Lerp(180f, 360f, player.statSpin / 10f); // Air rotation speed based on spin stat
                 float rotationAmount = rotationInput * rotationSpeed * dt;
                 player.AngularVelocity = new Vector3(0, rotationAmount / dt, 0); // Apply as angular velocity for smoother rotation
                 // Or apply directly to transform if preferred:
                 // player.transform.Rotate(Vector3.up, rotationAmount); 
             }
             else {
                 // Dampen angular velocity if no input
                  player.AngularVelocity = Vector3.Lerp(player.AngularVelocity, Vector3.zero, dt * 5f);
             }

             // Apply angular velocity to rotation
             player.transform.Rotate(player.AngularVelocity * dt, Space.World);
        }
        
        private void LimitAirSpeed()
        {
            // Limit max horizontal air speed if needed
             float maxAirSpeed = 25f; // Example max air speed
             Vector3 horizontalVelocity = new Vector3(player.Velocity.x, 0, player.Velocity.z);
             if (horizontalVelocity.sqrMagnitude > maxAirSpeed * maxAirSpeed)
             {
                 Vector3 limitedHorizontal = horizontalVelocity.normalized * maxAirSpeed;
                 player.Velocity = new Vector3(limitedHorizontal.x, player.Velocity.y, limitedHorizontal.z);
             }
        }

        private void HandleGrindInput()
        {
            // Use InputHeld for continuous checking while button is down
            if (inputHandler.GrindInputHeld)
            {
                // Attempt to find a rail below/ahead
                if (TryStickToRail()) // Changed from player.AttemptGrind()
                {
                    // State change is handled within TryStickToRail
                    // Consume input if needed (TryStickToRail might handle this)
                    // inputHandler.ConsumeGrindInputDown(); // Likely not needed if checking Held
                }
            }
        }

        // --- Added Grind Detection Method (Copied from Skating/Airborne) ---
        // Constants needed from other states (adjust if needed for PlayerVertAir)
        private const float RAIL_DETECTION_DISTANCE = 2.5f;
        private const float MIN_GRIND_SPEED = 2.0f;
        private const float MAX_VERTICAL_OFFSET = 2.0f;

        // Feelers (Use specific ones if needed, or reuse general ones)
        private readonly Vector3[] vertFeelerOffsets = new Vector3[]
        {
            // Basic feelers similar to skating/airborne
            new Vector3(-0.3f, -0.15f, 0.4f), new Vector3(0.0f, -0.15f, 0.4f), new Vector3(0.3f, -0.15f, 0.4f),
            new Vector3(-0.3f, -0.15f, 0.0f), new Vector3(0.0f, -0.15f, 0.0f), new Vector3(0.3f, -0.15f, 0.0f),
            new Vector3(-0.3f, -0.15f, -0.4f), new Vector3(0.0f, -0.15f, -0.4f), new Vector3(0.3f, -0.15f, -0.4f),
            // Side feelers might be less relevant in vert air?
            new Vector3(-0.4f, 0.0f, 0.0f), new Vector3(0.4f, 0.0f, 0.0f), 
        };
        private readonly Vector3[] vertRayDirections = new Vector3[]
        {
            // Primarily down/forward/backward
            new Vector3(0, -1, 0),                           
            new Vector3(0, -0.9f, 0.1f).normalized,          
            new Vector3(0, -0.9f, -0.1f).normalized,         
            new Vector3(0.1f, -0.9f, 0).normalized,          
            new Vector3(-0.1f, -0.9f, 0).normalized,         
            new Vector3(0, -0.7f, 0.3f).normalized,          
            new Vector3(0, -0.7f, -0.3f).normalized,
            // Less emphasis on horizontal/upward rays?
        };

        private bool TryStickToRail()
        {
            int railLayerMask = LayerMask.GetMask("Rail");
            RaycastHit bestHit = new RaycastHit();
            SplineGrindPath bestSplinePath = null;
            bool foundPotentialRail = false;
            float bestCombinedDistance = float.MaxValue;

            Debug.DrawRay(player.transform.position, Vector3.up * 0.5f, Color.cyan, 0.1f); // Use Cyan for PlayerVertAir

            foreach (Vector3 feelerOffset in vertFeelerOffsets) // Use vert-specific feelers
            {
                Vector3 feelerPos = player.transform.TransformPoint(feelerOffset);
                Debug.DrawLine(player.transform.position, feelerPos, Color.blue, 0.1f);

                foreach (Vector3 localDirection in vertRayDirections) // Use vert-specific directions
                {
                    Vector3 worldDirection = player.transform.TransformDirection(localDirection);
                    Debug.DrawRay(feelerPos, worldDirection * RAIL_DETECTION_DISTANCE, new Color(0.2f, 0.8f, 0.8f, 0.3f), 0.1f);

                    if (Physics.Raycast(feelerPos, worldDirection, out RaycastHit hit, RAIL_DETECTION_DISTANCE, railLayerMask))
                    {
                        SplineGrindPath splinePath = hit.collider.GetComponentInParent<SplineGrindPath>();
                        if (splinePath != null)
                        {
                            Vector3 delta = hit.point - feelerPos;
                            float verticalDistance = Mathf.Abs(Vector3.Dot(delta, hit.normal));
                            float horizontalDistance = Vector3.ProjectOnPlane(delta, hit.normal).magnitude;
                            float combinedDistance = horizontalDistance + verticalDistance * 0.5f;

                            if (verticalDistance <= MAX_VERTICAL_OFFSET || combinedDistance < RAIL_DETECTION_DISTANCE * 0.5f)
                            {
                                Debug.DrawLine(feelerPos, hit.point, Color.yellow, 0.1f);
                                Debug.DrawRay(hit.point, hit.normal * 0.5f, Color.red, 0.1f);

                                if (worldDirection.y < -0.5f && verticalDistance > MAX_VERTICAL_OFFSET)
                                {
                                    continue;
                                }

                                if (combinedDistance < bestCombinedDistance)
                                {
                                    bestCombinedDistance = combinedDistance;
                                    bestHit = hit;
                                    bestSplinePath = splinePath;
                                    foundPotentialRail = true;
                                }
                            }
                        }
                        // Removed warning spam if splinePath is null
                    }
                }
            }

            if (foundPotentialRail && bestSplinePath != null)
            {
                bool foundSplinePoint = bestSplinePath.GetNearestPoint(bestHit.point, out Vector3 closestSplinePoint, out Vector3 tangentAtSpline, out float distanceAlongSpline);
                Debug.Log($"PlayerVertAir: GetNearestPoint result: {foundSplinePoint} for hit point {bestHit.point} on spline {bestSplinePath.name}");

                if (foundSplinePoint)
                {
                    Vector3 playerVelocity = player.Velocity;
                    float playerSpeed = playerVelocity.magnitude;
                    Vector3 playerDirection = playerVelocity.normalized;

                    if (playerSpeed < MIN_GRIND_SPEED)
                    {
                        Debug.Log("PlayerVertAir: Failed Speed Check.");
                        return false;
                    }

                    float entryAngleThreshold = 60f; // Allow slightly larger angle from air?
                    float angle = Vector3.Angle(playerDirection, tangentAtSpline);
                    float oppositeAngle = Vector3.Angle(playerDirection, -tangentAtSpline);
                    float minAngle = Mathf.Min(angle, oppositeAngle);

                    if (minAngle > entryAngleThreshold)
                    {
                         Debug.Log($"PlayerVertAir: Failed Angle Check (Angle: {minAngle:F1} > {entryAngleThreshold})");
                        return false;
                    }

                    bool reverseDirection = Vector3.Dot(playerDirection, tangentAtSpline) < 0;
                    Vector3 forwardDir = reverseDirection ? -tangentAtSpline.normalized : tangentAtSpline.normalized;

                    // Perform Snap and Request Grind via PlayerController
                    float boardHeightOffset = 0.1f;
                    Vector3 snapPosition = closestSplinePoint + Vector3.up * boardHeightOffset;
                    player.transform.position = snapPosition; // Snap position
                    player.transform.rotation = Quaternion.LookRotation(forwardDir, Vector3.up); // Snap rotation

                    // Calculate entry speed and apply boost
                    float entrySpeed = Mathf.Max(Mathf.Abs(Vector3.Dot(playerVelocity, forwardDir)), MIN_GRIND_SPEED);
                    float boostedSpeed = entrySpeed * 1.2f;
                    player.Velocity = forwardDir * boostedSpeed; // Set velocity
                    
                    // Request the grind transition via PlayerController
                    player.RequestGrind(bestSplinePath, closestSplinePoint, forwardDir, distanceAlongSpline, bestHit.normal);

                    Debug.Log($"PlayerVertAir: Grind requested on spline: {bestSplinePath.name}");
                    // StateMachine.ChangeState(stateMachine.GrindingState); // Don't change state directly, let PlayerController handle it
                    return true; // Grind initiated
                }
                else
                {
                    Debug.LogWarning("PlayerVertAir: Found rail but failed to get closest point on spline.", bestSplinePath);
                }
            }
            return false;
        }
        // --- End Grind Detection Method ---

        public override void Exit()
        {
            Debug.Log("Exiting Player Vert Air State");
            // Reset any vert-specific flags
            // TODO: player.IsInVertAir = false;
            // Ensure angular velocity is reasonable on exit
            player.AngularVelocity *= 0.5f; 
        }
    }
} 