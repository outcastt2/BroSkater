using UnityEngine;
using BroSkater.Rails;

namespace BroSkater.Player.StateMachine
{
    // Renamed from PlayerGroundedState
    public class PlayerSkatingState : PlayerState
    {
        // Jump mechanics
        private bool isJumpCharging = false;
        private float jumpChargeTime = 0f;
        private const float MAX_JUMP_CHARGE_TIME = 1.0f;
        
        // Movement physics - most values now come from player stats
        private Vector3 moveDirection;
        private float currentSpeed; // Track speed separately
        private bool wasInAir = false; // Still needed for OnLanding logic
        
        // Landing transition tracking
        private bool isInLandingTransition = false;
        private float landingTransitionTimer = 0f;
        private const float LANDING_TRANSITION_TIME = 0.15f; 
        private Vector3 targetLandingDirection;
        
        // Manual detection
        // private bool isInManual = false; // Manual is its own state now
        // private float manualTimer = 0f;
        // private const float MANUAL_MIN_TIME = 0.25f; 

        // Standing/skating state
        // private bool isStandingStill = true; // REMOVED - This is the Skating state
        private const float MIN_SKATING_SPEED_THRESHOLD = 0.5f; // Speed below which we transition to StandingStill
        private const float PUSH_FORCE = 6.0f; // Force applied when transitioning from StandingStill
        
        // Ground rotation damping
        private const float GROUND_ROTATION_DAMPING = 20f; // Reduced damping for stability
        private const float MODEL_TILT_DAMPING = 15f; // Smoothing for model tilt
        
        // Updated rail detection parameters
        private const float RAIL_DETECTION_DISTANCE = 2.5f;  
        private const float MAX_VERTICAL_OFFSET = 2.0f;      
        private bool hasConsumedGrindInput = false;

        // --- Ground-Specific Feelers --- 
        // Only use lower feelers and primarily downward rays for ground detection
        private readonly Vector3[] groundStateFeelerOffsets = new Vector3[]
        {
            new Vector3(-0.3f, -0.15f, 0.4f),  // Front left
            new Vector3(0.0f, -0.15f, 0.4f),   // Front center
            new Vector3(0.3f, -0.15f, 0.4f),   // Front right
            new Vector3(-0.3f, -0.15f, 0.0f),  // Center left
            new Vector3(0.0f, -0.15f, 0.0f),   // Center
            new Vector3(0.3f, -0.15f, 0.0f),   // Center right
            new Vector3(-0.3f, -0.15f, -0.4f), // Back left
            new Vector3(0.0f, -0.15f, -0.4f),  // Back center
            new Vector3(0.3f, -0.15f, -0.4f),  // Back right
        };

        private readonly Vector3[] groundStateRayDirections = new Vector3[]
        {
            new Vector3(0, -1, 0),                           // Straight down
            new Vector3(0, -0.9f, 0.1f).normalized,          // Slightly forward-down
            new Vector3(0, -0.9f, -0.1f).normalized,         // Slightly backward-down
            new Vector3(0.1f, -0.9f, 0).normalized,          // Slightly right-down
            new Vector3(-0.1f, -0.9f, 0).normalized,         // Slightly left-down
            // Add a couple of slightly more outward rays for catching edges
            new Vector3(0.3f, -0.9f, 0).normalized, 
            new Vector3(-0.3f, -0.9f, 0).normalized,
        };
        // --- End Ground-Specific Feelers ---

        // Wheel and feeler offsets for rail detection (in local space)
        /*
        private readonly Vector3[] groundFeelerOffsets = new Vector3[]
        {
            // Front wheel area
            new Vector3(-0.3f, -0.15f, 0.4f),  // Front left
            new Vector3(0.0f, -0.15f, 0.4f),   // Front center
            new Vector3(0.3f, -0.15f, 0.4f),   // Front right
            
            // Center wheel area
            new Vector3(-0.3f, -0.15f, 0.0f),  // Center left
            new Vector3(0.0f, -0.15f, 0.0f),   // Center
            new Vector3(0.3f, -0.15f, 0.0f),   // Center right
            
            // Back wheel area 
            new Vector3(-0.3f, -0.15f, -0.4f), // Back left
            new Vector3(0.0f, -0.15f, -0.4f),  // Back center
            new Vector3(0.3f, -0.15f, -0.4f),  // Back right
            
            // Side feelers (for catching rails from the side)
            new Vector3(-0.4f, 0.0f, 0.0f),    // Left side
            new Vector3(0.4f, 0.0f, 0.0f),     // Right side
            
            // --- Added Higher/Side Feelers ---
            new Vector3(-0.3f, 0.0f, 0.4f),  // Front left (Level)
            new Vector3(0.3f, 0.0f, 0.4f),   // Front right (Level)
            new Vector3(-0.3f, 0.0f, -0.4f), // Back left (Level)
            new Vector3(0.3f, 0.0f, -0.4f),  // Back right (Level)
        };
        */

        // Multiple ray directions to cover different approaches
        /*
        private readonly Vector3[] rayDirections = new Vector3[]
        {
            new Vector3(0, -1, 0),                           // Straight down
            new Vector3(0, -0.9f, 0.1f).normalized,          // Slightly forward-down
            new Vector3(0, -0.9f, -0.1f).normalized,         // Slightly backward-down
            new Vector3(0.1f, -0.9f, 0).normalized,          // Slightly right-down
            new Vector3(-0.1f, -0.9f, 0).normalized,         // Slightly left-down
            new Vector3(0, -0.7f, 0.3f).normalized,          // More forward-down
            new Vector3(0, -0.7f, -0.3f).normalized,         // More backward-down
            
            // --- Added Horizontal & Upward --- 
            new Vector3(1, 0, 0),                            // Right
            new Vector3(-1, 0, 0),                           // Left
            new Vector3(0.707f, 0.707f, 0).normalized,       // Up-Right
            new Vector3(-0.707f, 0.707f, 0).normalized,      // Up-Left
            new Vector3(0, 0.3f, 1).normalized,             // Slightly Up-Forward
            new Vector3(0, 0.3f, -1).normalized,            // Slightly Up-Backward
        };
        */

        // Constructor - Renamed class
        public PlayerSkatingState(PlayerStateMachine stateMachine, PlayerController player) : base(stateMachine, player) { }

        public override void Enter()
        {
            Debug.Log("Entering Skating State"); // Renamed log
            player.IsGrounded = true; 
            
            // Reset jump state
            isJumpCharging = false;
            jumpChargeTime = 0f;
            
            // Reset grind input state
            hasConsumedGrindInput = false;
            
            // Handle state entry based on previous state 
            if (wasInAir)
            {
                OnLanding();
            }
            else if (stateMachine.PreviousState == stateMachine.StandingStillState)
            {
                // Apply initial push force when coming from Standstill
                player.Velocity += player.Forward * PUSH_FORCE;
                moveDirection = player.Forward; // Ensure move direction is set
                 Debug.Log("Applied Push Force from Standstill");
            }
            else
            {
                // Default continuation logic (e.g., from manual)
                OnGroundContinue();
            }
            
            // Initialize speed based on entry velocity projection
            currentSpeed = Vector3.ProjectOnPlane(player.Velocity, player.GetGroundNormal()).magnitude;
            
            // Manual state is handled separately
            // isInManual = false;
            // manualTimer = 0f;
            
            // isStandingStill flag removed
        }
        
        private void OnLanding()
        {
            // 1. Project velocity onto ground plane immediately
            Vector3 groundNormal = player.GetGroundNormal();
            Vector3 horizontalVelocity = Vector3.ProjectOnPlane(player.Velocity, groundNormal);
            float currentSpeed = horizontalVelocity.magnitude;
            
            // 2. Set initial move direction and blend with velocity
            if (currentSpeed > 1.0f)
            {
                // Get normalized directions
                Vector3 velocityDir = horizontalVelocity.normalized;
                Vector3 facingDir = player.Forward;
                
                // Calculate dot product to determine alignment
                float alignmentDot = Vector3.Dot(velocityDir, facingDir);
                
                // More strongly align with facing direction when landing
                float spinFactor = Mathf.Lerp(0.4f, 0.8f, player.statSpin / 10f);
                float facingBias = Mathf.Lerp(0.9f, 0.8f, currentSpeed / 15f);
                
                // Extra alignment for backward landings
                if (alignmentDot < 0)
                {
                    facingBias += 0.1f;
                    currentSpeed *= 0.8f;
                }
                
                // Apply spin stat influence
                facingBias = Mathf.Lerp(facingBias, 1.0f, spinFactor);
                
                // Create blended direction - heavily biased toward facing
                Vector3 blendedDirection = Vector3.Lerp(velocityDir, facingDir, facingBias).normalized;
                
                // Apply the blended velocity with speed reduction
                float speedRetention = Mathf.Lerp(0.7f, 0.9f, alignmentDot * 0.5f + 0.5f);
                Vector3 newVelocity = blendedDirection * currentSpeed * speedRetention;
                
                // 3. Snap transform rotation to face movement direction and zero angular velocity
                player.transform.rotation = Quaternion.LookRotation(blendedDirection, Vector3.up);
                player.AngularVelocity = Vector3.zero;
                
                // Set velocity and move direction
                player.Velocity = newVelocity;
                moveDirection = blendedDirection;
                currentSpeed = newVelocity.magnitude; // Update tracked speed
                
                // Set up landing transition
                isInLandingTransition = true;
                landingTransitionTimer = 0f;
                targetLandingDirection = facingDir;
                
                Debug.Log($"Landing velocity: orig={currentSpeed:F1}, new={newVelocity.magnitude:F1}, bias={facingBias:F2}, retention={speedRetention:F2}");
            }
            else
            {
                // For very low speeds, align with facing and zero momentum
                moveDirection = player.Forward;
                player.transform.rotation = Quaternion.LookRotation(moveDirection, Vector3.up);
                player.AngularVelocity = Vector3.zero;
                player.Velocity = moveDirection * currentSpeed * 0.7f;
                currentSpeed *= 0.7f; // Update tracked speed
            }
            
            // Apply stronger landing friction
            player.Velocity *= 0.98f; // Apply only a very minor damping on landing
            currentSpeed *= 0.98f; // Update tracked speed after damping
            
            // Clear the air flag
            wasInAir = false;
        }
        
        private void OnGroundContinue()
        {
            // Get horizontal velocity components
            Vector3 horizontalVelocity = Vector3.ProjectOnPlane(player.Velocity, player.GetGroundNormal());
            
            // Keep horizontal velocity but apply some friction
            player.Velocity = horizontalVelocity * 0.95f;
            currentSpeed = player.Velocity.magnitude; // Update tracked speed
            
            // Set initial move direction based on velocity or facing
            if (horizontalVelocity.magnitude > 1.0f)
            {
                moveDirection = horizontalVelocity.normalized;
            }
            else
            {
                moveDirection = player.Forward;
            }
        }

        public override void LogicUpdate()
        {
            // Update landing transition if active
            if (isInLandingTransition)
            {
                UpdateLandingTransition();
            }
            
            // Ground detection <<< REMOVE THIS BLOCK
            // player.CheckGrounded();
            // 
            // // Check if we've lost ground contact
            // if (!player.IsGrounded)
            // {
            //     wasInAir = true;
            //     stateMachine.ChangeState(stateMachine.AirborneState);
            //     return;
            // }
            // <<< END REMOVAL

            // Handle jump input (ollie)
            HandleJumpInput();
            
            // Check for manual input
            float verticalInput = inputHandler.MoveInput.y;
            if (Mathf.Abs(verticalInput) > 0.8f && player.Speed > PlayerManualState.MIN_MANUAL_SPEED)
            {
                stateMachine.ChangeState(stateMachine.ManualState);
                return;
            }
        }
        
        private void UpdateLandingTransition()
        {
            // Increment timer
            landingTransitionTimer += Time.deltaTime;
            
            if (landingTransitionTimer < LANDING_TRANSITION_TIME)
            {
                // During the transition period, continue to align velocity with facing direction
                Vector3 horizontalVelocity = new Vector3(player.Velocity.x, 0, player.Velocity.z);
                float currentSpeed = horizontalVelocity.magnitude;
                
                if (currentSpeed > 0.5f)
                {
                    // Calculate progress through transition (0-1)
                    float transitionProgress = landingTransitionTimer / LANDING_TRANSITION_TIME;
                    
                    // Progressively strengthen alignment as we move through transition
                    // Start at 20% alignment, end at 60% alignment per frame
                    float alignFactor = Mathf.Lerp(0.2f, 0.6f, transitionProgress);
                    
                    // Blend current velocity toward the target direction
                    Vector3 currentDir = horizontalVelocity.normalized;
                    Vector3 blendedDir = Vector3.Lerp(currentDir, targetLandingDirection, alignFactor).normalized;
                    
                    // Apply the new velocity direction but maintain speed
                    player.Velocity = blendedDir * currentSpeed;
                    
                    // Update move direction to match the blended direction
                    moveDirection = blendedDir;
                }
            }
            else
            {
                // End the landing transition
                isInLandingTransition = false;
            }
        }

        // Modified to ONLY update moveDirection based on input, ROTATING AROUND NORMAL
        private void HandleRotation(float dt, Vector3 groundNormal) 
        {
            float rotationInput = inputHandler.MoveInput.x;

            // Get the player's current forward projected onto the ground plane
            Vector3 currentForwardOnPlane = Vector3.ProjectOnPlane(player.Forward, groundNormal).normalized;
             if (currentForwardOnPlane == Vector3.zero) { currentForwardOnPlane = Vector3.ProjectOnPlane(player.transform.forward, groundNormal).normalized; } // Fallback
             
            if (Mathf.Abs(rotationInput) > 0.1f)
            {
                float speedFactor = Mathf.Clamp01(player.Velocity.magnitude / 5.0f); 
                float rotationSpeed = Mathf.Lerp(120f, 180f, player.statSpin / 10f);
                float rotationAmount = rotationInput * rotationSpeed * dt; 
                rotationAmount *= Mathf.Lerp(1.0f, 0.7f, speedFactor);
                
                // Calculate the target direction by rotating the current forward on plane
                Vector3 targetDirection = Quaternion.AngleAxis(rotationAmount, groundNormal) * currentForwardOnPlane; 
                moveDirection = targetDirection.normalized; // Set move direction directly
           }
            else if (player.Velocity.magnitude < MIN_SKATING_SPEED_THRESHOLD)
            {
                 // If slow and no input, align move direction with current facing on plane
                 moveDirection = currentForwardOnPlane;
            }
            // Else (coasting with speed but no input), moveDirection retains its value from the last input/frame
            
            // Remove final projection - moveDirection is already calculated on the plane
            // moveDirection = Vector3.ProjectOnPlane(moveDirection, groundNormal).normalized;
            // if (moveDirection == Vector3.zero)
            // { moveDirection = Vector3.ProjectOnPlane(player.Forward, groundNormal).normalized;} 
        }

        private void HandleJumpInput()
        {
            if (inputHandler.JumpInputDown && !isJumpCharging)
            {
                // Start charging jump
                isJumpCharging = true;
                jumpChargeTime = 0f;
                inputHandler.ConsumeJumpInputDown();
                
                // Apply an immediate small boost when starting to charge
                player.Velocity += moveDirection * 1.5f;
            }
            else if (inputHandler.JumpInputHeld && isJumpCharging)
            {
                // Continue charging jump
                jumpChargeTime += Time.deltaTime;
                
                // Cap charge time at maximum but don't automatically jump
                jumpChargeTime = Mathf.Min(jumpChargeTime, MAX_JUMP_CHARGE_TIME);
            }
            else if (inputHandler.JumpInputUp && isJumpCharging)
            {
                // Jump button released, execute jump with current charge
                ExecuteJump();
                inputHandler.ConsumeJumpInputUp();
            }
        }
        
        private void ExecuteJump()
        {
            // Calculate jump force based on player stats and charge time
            float chargeRatio = Mathf.Clamp01(jumpChargeTime / MAX_JUMP_CHARGE_TIME);
            // Get base jump force using stat
            float baseJumpForce = player.PhysicsParams.GetValueFromStat(player.PhysicsParams.ollieJumpForce, player.statOllie, player.IsSwitch);
            // Lerp based on charge (maybe make charge influence a parameter?)
            float jumpForce = Mathf.Lerp(baseJumpForce * 0.5f, baseJumpForce, chargeRatio); // Example: 50% to 100% force based on charge
            
            // Check if launching from vert for potentially different force
            bool onVert = player.CheckVertexColor(player.LastGroundHit, player.PhysicsParams.vertColor);
            float finalJumpForce = jumpForce; // Default to regular ollie force
            if (onVert)
            {
                // Use vert-specific force (can still be influenced by charge and stats if desired)
                float vertBaseForce = player.PhysicsParams.GetValueFromStat(player.PhysicsParams.vertJumpForce, player.statOllie, player.IsSwitch);
                finalJumpForce = Mathf.Lerp(vertBaseForce * 0.5f, vertBaseForce, chargeRatio); // Apply charge influence to vert jump too
                 Debug.Log($"Using VERT Jump Force: {finalJumpForce}");
            }

            // Add more force if special is active
            if (player.IsSpecialActive())
            {
                finalJumpForce *= 1.2f; // Make this multiplier a parameter?
            }
            
            // Retain horizontal velocity 
            Vector3 currentHorizontalVel = Vector3.ProjectOnPlane(player.Velocity, Vector3.up);
            float horizontalRetentionFactor = player.PhysicsParams.GetValue(player.PhysicsParams.jumpHorizontalRetention, player.IsSwitch);
            
            // Combine retained horizontal velocity with the PURELY VERTICAL jump force
            player.Velocity = currentHorizontalVel * horizontalRetentionFactor + Vector3.up * finalJumpForce;
            
            // Set the justOllied flag and timer in PlayerController
            player.justOllied = true;
            player.SetIgnoreGroundTimer(0.15f); // Consistent timer value
            
            // Reset jump variables
            isJumpCharging = false;
            jumpChargeTime = 0f;
            
            // Mark that we're going into air state
            wasInAir = true;
            
            // --- Transition to Correct Air State ---
            if (onVert)
            {
                Vector3 launchPos = player.transform.position;
                Debug.Log($"ExecuteJump (SkatingState): On VERT -> Transitioning to VertAirState. Launch Pos: {launchPos}");
                stateMachine.VertAirState.EnterWithVertLaunch(launchPos);
                stateMachine.ChangeState(stateMachine.VertAirState);
            }
            else
            {
                Debug.Log($"ExecuteJump (SkatingState): Not on VERT -> Transitioning to AirborneState");
                stateMachine.ChangeState(stateMachine.AirborneState);
            }
            // --- End Transition ---
        }
        
        public override void PhysicsUpdate()
        {
            Debug.Log("--- SkatingState PhysicsUpdate --- ACTIVE"); // Log state activity
            float dt = Time.fixedDeltaTime;
            
            // Get Ground Normal ONCE
            Vector3 currentGroundNormal = player.GetGroundNormal(); 
            if (currentGroundNormal == Vector3.zero) currentGroundNormal = Vector3.up; 

            // ALWAYS apply skating physics in this state
            // 1. Handle Rotation Calculation (Pass Normal)
            HandleRotation(dt, currentGroundNormal);
            
            // 2. Align Main Player Rotation (Yaw Only) - Still uses World Up for main transform stability
            Quaternion targetYawRot = Quaternion.LookRotation(moveDirection, Vector3.up); 
            player.transform.rotation = Quaternion.Slerp(
                player.transform.rotation,
                targetYawRot,
                GROUND_ROTATION_DAMPING * dt 
            );
            // moveDirection = player.Forward; // Update moveDirection based on yaw slerp <<< REMOVE THIS

            // --- Align Visual Models (Tilt) ---
            AlignModelsToNormal(currentGroundNormal); // Uses normal for tilt
            
            // 3. Calculate and Apply Target Velocity 
            CalculateAndApplyVelocity(dt, currentGroundNormal); // Uses normal for projection logic
            Debug.Log($"SkatingState: Post-Velocity Apply. Velocity = {player.Velocity}, MoveDirection = {moveDirection}"); // Log velocity and move dir
            
            // 4. Apply Slope Forces (uses groundNormal) - DISABLED FOR GROUNDED
            // player.ApplySlopeForces();
            
            // 5. Project velocity onto ground plane again to prevent slope climbing <<< REMOVED (Done in Apply Velocity)
            // player.Velocity = Vector3.ProjectOnPlane(player.Velocity, player.GetGroundNormal());
            
            // 6. Apply Ground Friction <<< REMOVED (Done in Apply Velocity)
            // ApplyGroundFriction(dt);
            
            // 7. Limit to Top Speed <<< REMOVED (Done in Apply Velocity)
            // LimitSpeed();
            
            // --- Modified Grind Check --- 
            // Check for rail every physics frame if grind input is HELD and hasn't been consumed yet
            if (inputHandler.GrindInputHeld && !hasConsumedGrindInput && // Changed from GrindInputDown
                player.Velocity.magnitude >= MIN_SKATING_SPEED_THRESHOLD)
            {
                if (TryStickToRail())
                {
                    // Successfully found a rail and transitioned to grind state
                    hasConsumedGrindInput = true; // Consume the input now
                    // inputHandler.ConsumeGrindInputDown(); // No longer need to consume the 'Down' event here
                    return; // Exit physics update as state changed
                }
                // If TryStickToRail fails, do nothing, it will check again next physics frame while held
            }
            // --- End Modified Grind Check ---
        }
        
        private void AlignMovementToVelocity()
        {
            // Get horizontal velocity
            Vector3 horizontalVelocity = new Vector3(player.Velocity.x, 0, player.Velocity.z);
            
            // If we have meaningful velocity, align movement direction to it
            if (horizontalVelocity.magnitude > 2.0f)
            {
                moveDirection = horizontalVelocity.normalized;
            }
            else
            {
                // Otherwise use current forward
                moveDirection = player.Forward;
            }
        }

        // Method to align visual models
        private void AlignModelsToNormal(Vector3 groundNormal)
        {
            // Calculate the target tilt rotation based on the ground normal
            Quaternion targetTilt = Quaternion.FromToRotation(Vector3.up, groundNormal);
            
            // Smoothly interpolate the models' local rotation towards the target tilt
            if (player.PlayerModel != null) 
                player.PlayerModel.localRotation = Quaternion.Slerp(
                    player.PlayerModel.localRotation, 
                    targetTilt, 
                    Time.deltaTime * MODEL_TILT_DAMPING
                );
            if (player.SkateboardModel != null) 
                player.SkateboardModel.localRotation = Quaternion.Slerp(
                    player.SkateboardModel.localRotation, 
                    targetTilt, 
                    Time.deltaTime * MODEL_TILT_DAMPING
                );
        }

        // --- Updated Grind Detection Method (Grounded) ---
        private bool TryStickToRail()
        {
            // Use parameter for min speed
            float minGrindSpeed = player.PhysicsParams.GetValue(player.PhysicsParams.minGrindSpeed, player.IsSwitch);
            
            int railLayerMask = LayerMask.GetMask("Rail");
            RaycastHit bestHit = new RaycastHit();
            SplineGrindPath bestSplinePath = null;
            bool foundPotentialRail = false;
            float bestCombinedDistance = float.MaxValue;

            Debug.DrawRay(player.transform.position, Vector3.up * 0.5f, Color.white, 0.1f);

            // Use Ground-Specific Arrays
            foreach (Vector3 feelerOffset in groundStateFeelerOffsets)
            {
                Vector3 feelerPos = player.transform.TransformPoint(feelerOffset);
                Debug.DrawLine(player.transform.position, feelerPos, Color.blue, 0.1f);

                foreach (Vector3 localDirection in groundStateRayDirections)
                {
                    Vector3 worldDirection = player.transform.TransformDirection(localDirection);
                    Debug.DrawRay(feelerPos, worldDirection * RAIL_DETECTION_DISTANCE, new Color(0.2f, 0.8f, 0.2f, 0.3f), 0.1f);

                    if (Physics.Raycast(feelerPos, worldDirection, out RaycastHit hit, RAIL_DETECTION_DISTANCE, railLayerMask))
                    {
                         // Try to get the SplineGrindPath component
                        SplineGrindPath splinePath = hit.collider.GetComponentInParent<SplineGrindPath>();
                        if (splinePath == null) 
                        {
                            Debug.LogWarning($"Raycast hit {hit.collider.name}, but NO SplineGrindPath component found in parent.", hit.collider.gameObject);
                        }
                        else if (splinePath != null)
                        {
                            Vector3 delta = hit.point - feelerPos;
                            float verticalDistance = Mathf.Abs(Vector3.Dot(delta, hit.normal));
                            float horizontalDistance = Vector3.ProjectOnPlane(delta, hit.normal).magnitude;
                            float combinedDistance = horizontalDistance + verticalDistance * 0.5f;

                            if (verticalDistance <= MAX_VERTICAL_OFFSET || combinedDistance < RAIL_DETECTION_DISTANCE * 0.5f)
                            {
                                Debug.DrawLine(feelerPos, hit.point, Color.yellow, 0.1f);
                                Debug.DrawRay(hit.point, hit.normal * 0.5f, Color.red, 0.1f);
                                Debug.Log($"Rail detected: vert={verticalDistance:F2}, horiz={horizontalDistance:F2}, speed={player.Velocity.magnitude:F2}");

                                if (worldDirection.y < -0.5f && verticalDistance > MAX_VERTICAL_OFFSET)
                                {
                                    continue;
                                }

                                if (combinedDistance < bestCombinedDistance)
                                {
                                    bestCombinedDistance = combinedDistance;
                                    bestHit = hit;
                                    bestSplinePath = splinePath;
                                    foundPotentialRail = true;
                                }
                            }
                        }
                    }
                }
            }

            // If we found a potential rail, proceed with snapping and state change
            if (foundPotentialRail && bestSplinePath != null)
            {
                // Get the closest point ON THE SPLINE to the raycast hit point
                bool foundSplinePoint = bestSplinePath.GetNearestPoint(bestHit.point, out Vector3 closestSplinePoint, out Vector3 tangentAtSpline, out float distanceAlongSpline);
                
                // --- Add Log Here ---
                Debug.Log($"Grounded: GetNearestPoint result: {foundSplinePoint} for hit point {bestHit.point} on spline {bestSplinePath.name}");
                // --------------------

                if (foundSplinePoint)
                {
                    Debug.Log("Grounded: Found valid spline point."); // Log success
                    // Check entry angle and speed (similar to GrindDetector)
                    Vector3 playerVelocity = player.Velocity; // Use player velocity
                    float playerSpeed = playerVelocity.magnitude;
                    Vector3 playerDirection = playerVelocity.normalized;

                    // Log Speed Check
                    Debug.Log($"Grounded: Speed Check - Player Speed: {playerSpeed:F2}, Min Grind Speed: {minGrindSpeed}");
                    if (playerSpeed < minGrindSpeed)
                    {
                        Debug.Log("Grounded: Failed Speed Check.");
                        return false;
                    }

                    float entryAngleThreshold = 60f; // Use a threshold
                    float angle = Vector3.Angle(playerDirection, tangentAtSpline);
                    float oppositeAngle = Vector3.Angle(playerDirection, -tangentAtSpline);
                    float minAngle = Mathf.Min(angle, oppositeAngle);

                    // Log Angle Check
                    Debug.Log($"Grounded: Angle Check - PlayerDir: {playerDirection}, SplineTangent: {tangentAtSpline}, Min Angle: {minAngle:F2}, Threshold: {entryAngleThreshold}");
                    if (minAngle > entryAngleThreshold)
                    {
                        Debug.Log($"Grounded: Failed Angle Check.");
                        return false;
                    }

                    // Determine grind direction based on velocity vs tangent
                    bool reverseDirection = Vector3.Dot(playerDirection, tangentAtSpline) < 0;
                    Vector3 forwardDir = reverseDirection ? -tangentAtSpline.normalized : tangentAtSpline.normalized;

                    // --- Perform Snap (Similar to GrindDetector.BeginGrind) ---
                    float boardHeightOffset = 0.1f;
                    Vector3 newPosition = closestSplinePoint + Vector3.up * boardHeightOffset;
                    player.transform.position = newPosition;
                    player.transform.rotation = Quaternion.LookRotation(forwardDir, Vector3.up);

                    // --- Set Initial Velocity ---
                    float entrySpeed = Mathf.Max(
                        Mathf.Abs(Vector3.Dot(playerVelocity, forwardDir)),
                        minGrindSpeed 
                    );
                    // Use parameter for boost multiplier
                    float boostMultiplier = player.PhysicsParams.GetValue(player.PhysicsParams.grindEntrySpeedBoostMultiplier, player.IsSwitch);
                    float boostedSpeed = entrySpeed * boostMultiplier; 
                    player.Velocity = forwardDir * boostedSpeed;

                    // --- Notify State Machine ---
                    Debug.Log($"Grounded: Starting grind on spline: {bestSplinePath.name}, distance: {distanceAlongSpline:F2}m");
                    stateMachine.GrindingState.SetRailInfo(bestSplinePath, closestSplinePoint, forwardDir, distanceAlongSpline, bestHit.normal);
                    stateMachine.ChangeState(stateMachine.GrindingState);
                    return true;
                }
                else
                {
                     Debug.LogWarning("Grounded: Found rail but failed to get closest point on spline.", bestSplinePath);
                }
            }

            return false;
        }

        // NEW METHOD for velocity control
        private void CalculateAndApplyVelocity(float dt, Vector3 groundNormal)
        {
            // Use and update the tracked currentSpeed field
            // float currentSpeedOnPlane = Vector3.ProjectOnPlane(player.Velocity, groundNormal).magnitude; // REMOVED
            float targetSpeedThisFrame = 0f; // Local variable for this frame's target

            // --- Handle Jump Charging OR Regular Movement --- 
            if (isJumpCharging) 
            { 
                // Use parameter for boost range, scale by charge time
                float chargeRatio = Mathf.Clamp01(jumpChargeTime / MAX_JUMP_CHARGE_TIME);
                float baseBoost = player.PhysicsParams.GetValueFromStat(player.PhysicsParams.jumpChargeBoost, player.statAccel, player.IsSwitch); // Use accel stat?
                float chargeBoost = baseBoost * chargeRatio;
                 
                Vector3 boostDir = moveDirection; 
                Vector3 boostVel = Vector3.ProjectOnPlane(boostDir * chargeBoost * dt, groundNormal);
                Vector3 velocityBeforeLimit = player.Velocity + boostVel; 
                
                // Calculate the speed *after* boost is potentially added
                float speedAfterBoost = Vector3.ProjectOnPlane(velocityBeforeLimit, groundNormal).magnitude;
                
                // Limit speed while charging
                float maxChargeSpeed = Mathf.Lerp(15f, 20f, player.statSpeed / 10f);
                targetSpeedThisFrame = Mathf.Min(speedAfterBoost, maxChargeSpeed);
                // Removed direct velocity limit application here
            }
            else // Regular Movement (Not Charging)
            {
                // Determine target speed based on input using the tracked currentSpeed
                float forwardInput = inputHandler.MoveInput.y;
                bool isExplicitlyBraking = forwardInput < -0.1f;
                bool isPushing = forwardInput > 0.1f;
                
                float maxPushSpeed = Mathf.Lerp(12f, 18f, player.statSpeed / 10f);
                float maxCoastSpeed = maxPushSpeed * 0.9f;
                if (player.IsSpecialActive()) maxPushSpeed += 5.0f;
                
                float accelerationRate = player.statAccel * 2.0f;
                float coastDecelerationRate = 0.1f;
                float brakeDecelerationRate = 15.0f;

                if (isExplicitlyBraking)
                {
                    targetSpeedThisFrame = Mathf.Max(0f, currentSpeed - brakeDecelerationRate * dt);
                }
                else if (isPushing)
                {
                    targetSpeedThisFrame = Mathf.Min(maxPushSpeed, currentSpeed + accelerationRate * dt); 
                }
                else // Coasting
                {
                    targetSpeedThisFrame = Mathf.Min(maxCoastSpeed, currentSpeed);
                    targetSpeedThisFrame = Mathf.Max(0f, targetSpeedThisFrame); 
                }
            }
            // --- END JUMP CHARGE OR REGULAR MOVEMENT ---

            // --- Update the tracked currentSpeed --- 
            currentSpeed = targetSpeedThisFrame;

            // --- Calculate Final Velocity Vector based on direction and speed ---
            Vector3 targetVelocity = moveDirection * currentSpeed; // Use updated tracked speed

            // --- Angle-Based Velocity Application (Applies to both charging and regular) ---
            /* // Start Comment Out
            float verticality = 1.0f - Mathf.Clamp01(Vector3.Dot(groundNormal, Vector3.up)); 
            float projectionThreshold = 0.1f; 

            if (verticality > (1.0f - projectionThreshold)) 
            {
                player.Velocity = targetVelocity; 
                // Debug.Log("Applying Direct Velocity (Steep Slope)");
            }
            else
            {
                Vector3 projectedTargetVelocity = Vector3.ProjectOnPlane(targetVelocity, groundNormal);
                player.Velocity = projectedTargetVelocity;
                // Debug.Log("Applying Projected Velocity (Gentle Slope)");
            }
            */ // End Comment Out
            
            // --- ALWAYS Project Velocity Onto Ground Normal --- 
            Vector3 projectedTargetVelocity = Vector3.ProjectOnPlane(targetVelocity, groundNormal);
            player.Velocity = projectedTargetVelocity;
            // --- End Angle-Based Velocity --- 
        }

        // private Vector3 _velocitySmoothRef; // Needed for SmoothDamp option

        public override void Exit()
        {
            // Reset state variables
            isJumpCharging = false;
            jumpChargeTime = 0f;
            hasConsumedGrindInput = false;
            isInLandingTransition = false; // Ensure landing transition stops
            
            // Manual state logic removed
        }
    }
} 
