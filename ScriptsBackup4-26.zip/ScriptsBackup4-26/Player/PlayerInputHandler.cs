using UnityEngine;

namespace BroSkater.Player
{
    // Basic input handler using Unity's old Input Manager.
    // Replace with Input System package if preferred.
    public class PlayerInputHandler : MonoBehaviour
    {
        public Vector2 MoveInput { get; private set; }
        public bool JumpInputDown { get; private set; } // True the frame jump is pressed
        public bool JumpInputHeld { get; private set; } // True while jump is held
        public bool JumpInputUp { get; private set; }   // True the frame jump is released
        public bool PushInput { get; private set; }    // True the frame W/Up is pressed
        public bool BrakeInputHeld { get; private set; } // True while S/Down is held
        public bool GrindInputDown { get; private set; } // True the frame grind is pressed
        public bool GrindInputHeld { get; private set; } // True while grind is held
        // Add trick inputs
        public bool TrickInputDown { get; private set; } // Kickflip (True the frame trick input is pressed)
        public bool TrickAltInputDown { get; private set; } // Heelflip (True the frame alt trick input is pressed)
        public bool Special1InputDown { get; private set; } // 360 Flip (True the frame special1 input is pressed)

        void Update()
        {
            // Reset single-frame inputs
            JumpInputDown = false;
            JumpInputUp = false;
            PushInput = false;
            GrindInputDown = false;
            TrickInputDown = false;
            TrickAltInputDown = false;
            Special1InputDown = false;

            // Read movement axes
            MoveInput = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxisRaw("Vertical")); // Use GetAxisRaw for vertical to detect tap easier

            // Read jump button states
            JumpInputDown = Input.GetButtonDown("Jump");
            JumpInputHeld = Input.GetButton("Jump");
            JumpInputUp = Input.GetButtonUp("Jump");

            // Read push input (Tap W/Up)
            // Check if vertical axis was just pressed *and* is positive
            if (Input.GetButtonDown("Vertical") && MoveInput.y > 0.5f) // GetButtonDown checks the button itself, not just axis value change
            {
                PushInput = true;
            }
             // Alternative Push Check (if "Vertical" isn't a dedicated button): Check if axis *became* positive this frame
             // float verticalRaw = Input.GetAxisRaw("Vertical");
             // bool currentlyPushing = verticalRaw > 0.5f;
             // bool wasPushingLastFrame = _previousVerticalRaw > 0.5f; // Need to store _previousVerticalRaw
             // PushInput = currentlyPushing && !wasPushingLastFrame;
             // _previousVerticalRaw = verticalRaw; // Store for next frame


            // Read brake input (Hold S/Down)
            BrakeInputHeld = MoveInput.y < -0.5f;

            // Read grind button
            GrindInputDown = Input.GetButtonDown("Grind");
            GrindInputHeld = Input.GetButton("Grind");
            
            // Read trick buttons
            TrickInputDown = Input.GetButtonDown("Fire1"); // Typically mapped to left ctrl/mouse button
            TrickAltInputDown = Input.GetButtonDown("Fire2"); // Typically mapped to left alt/right mouse button
            Special1InputDown = Input.GetButtonDown("Fire3"); // Typically mapped to left shift/middle mouse button

            // Consume inputs immediately if needed elsewhere, or let states consume them
        }

        // Optional: Methods to consume input after processing (States should call these)
        public void ConsumeJumpInputDown() => JumpInputDown = false;
        public void ConsumeJumpInputUp() => JumpInputUp = false;
        public void ConsumePushInput() => PushInput = false;
        public void ConsumeGrindInputDown() => GrindInputDown = false;
        public void ConsumeTrickInputDown() => TrickInputDown = false;
        public void ConsumeTrickAltInputDown() => TrickAltInputDown = false;
        public void ConsumeSpecial1InputDown() => Special1InputDown = false;
    }
} 