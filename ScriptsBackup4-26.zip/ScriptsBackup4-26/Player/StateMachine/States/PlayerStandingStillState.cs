using UnityEngine;

namespace BroSkater.Player.StateMachine
{
    public class PlayerStandingStillState : PlayerState
    {
        private const float STANDING_FRICTION = 0.85f; // Heavy friction to stop quickly
        private const float ROTATION_SPEED = 120f;

        public PlayerStandingStillState(PlayerStateMachine stateMachine, PlayerController player) : base(stateMachine, player) { }

        public override void Enter()
        {
            Debug.Log("Entering StandingStill State");
            player.IsGrounded = true; 
            // Ensure velocity is minimal upon entering
            player.Velocity *= 0.5f; // Significantly cut speed on entry
            player.AngularVelocity = Vector3.zero;
        }

        public override void LogicUpdate()
        {
            // Check for ground loss
            player.CheckGrounded();
            if (!player.IsGrounded)
            {
                stateMachine.ChangeState(stateMachine.AirborneState);
                return;
            }

            // Check for push input to start skating
            float forwardInput = inputHandler.MoveInput.y;
            if (forwardInput > 0.5f && inputHandler.PushInput) // Use PushInput for explicit push
            {
                // Apply initial push force directly in PlayerController or here?
                // Let's apply it in SkatingState.Enter for consistency.
                inputHandler.ConsumePushInput(); 
                stateMachine.ChangeState(stateMachine.SkatingState); // Change to SkatingState
                return;
            }
            
            // Allow rotation while standing still
            HandleRotation();
        }

        public override void PhysicsUpdate()
        {
            // Apply heavy friction to bring player to a stop
            player.Velocity *= Mathf.Pow(STANDING_FRICTION, Time.fixedDeltaTime * 60f);
            
            // Ensure player stays snapped to ground (minimal downward force if needed)
            if (player.IsGrounded) 
            {
               player.Velocity = Vector3.ProjectOnPlane(player.Velocity, player.GetGroundNormal());
               // Apply slight downward force if needed to prevent floating
               // if (player.Velocity.y > -0.1f) player.Velocity += Vector3.down * 0.5f * Time.fixedDeltaTime;
            }
            else 
            {
                // Apply gravity if somehow ground check failed mid-frame
                player.Velocity += Physics.gravity * Time.fixedDeltaTime;
            }
        }
        
        private void HandleRotation()
        {
            float rotationInput = inputHandler.MoveInput.x;
            if (Mathf.Abs(rotationInput) > 0.1f)
            {
                float rotationAmount = rotationInput * ROTATION_SPEED * Time.deltaTime;
                player.transform.Rotate(Vector3.up, rotationAmount);
            }
        }

        public override void Exit()
        {
            // Optional: Any cleanup when exiting standstill
        }
    }
} 